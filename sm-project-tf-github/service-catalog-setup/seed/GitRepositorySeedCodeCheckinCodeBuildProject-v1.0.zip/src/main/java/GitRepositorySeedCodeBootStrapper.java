import com.amazonaws.arn.Arn;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import net.lingala.zip4j.ZipFile;
import org.apache.commons.io.FileUtils;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.eclipse.jgit.transport.RefSpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.config.server.support.AwsCodeCommitCredentialProvider;

import java.io.File;
import java.io.IOException;
import java.lang.Exception;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

/**
 * Seed Code Checkin to Git Repository
 *
 */
public class GitRepositorySeedCodeBootStrapper
{
    private static final Logger logger = LoggerFactory.getLogger(GitRepositorySeedCodeBootStrapper.class);
    private static final String ORIGIN_REMOTE_REPOSITORY_NAME = "origin";
    private static final String SEEDCODE_COMMITTER_NAME = "AWS-Sagemaker";
    private static final String SEEDCODE_COMMITTER_EMAIL = "noreply-aws@amazon.com";
    private static final String SEEDCODE_COMMIT_MESSAGE =
            String.format("Initial commit made by %s during MLOps CI/CD pipeline creation", SEEDCODE_COMMITTER_NAME);
    private static final String TEMP_PATH = "/tmp/";
    private static final String SEEDCODE_LOCAL_PATH_ZIP_FILE = TEMP_PATH + "seedcode.zip";
    private static final String SEEDCODE_SUBSTITUTION_FILE_SEPARATOR = ",";
    private static final String FILE_ENCODING = "UTF-8";
    public static void main( String[] args ) throws Exception {
        try {
            File localRepoPath = new File(TEMP_PATH + getRepositoryFullName());
            cleanupLocalRepository(localRepoPath);
            URL cloneUrl = new URL(
                    getCodeStarConnectionsEndpointUrl(getRegion()),
                    getPath(getRepositoryFullName(), getConnectionArn()));
            CredentialsProvider gitCredentialsProvider = new AwsCodeCommitCredentialProvider();

            //Checkout the git repo code to local repo
            Git git = getGitRepository(cloneUrl, localRepoPath, gitCredentialsProvider);
            git.checkout().setName(getRepositoryBranch()).call();

            if (!isSeedCodeAlreadyBeenPushed(git)) {
                //Download and extract seedcode to local repo
                downloadModelBuildSeedcodeToLocal();
                extractSeedCode();
                if (System.getenv("SEED_CODE_UPDATE_FILE_NAME") != null) {
                    updateSeedCode();
                }

                //Push the seedcode to the repository
                commitAndPushAllFiles(git, gitCredentialsProvider);
                logger.info("Successfully pushed the seedcode");
            } else {
                throw new Exception("Seedcode is already present in this repository. Please use a different repository");
            }
        }
        catch (Exception e) {
            logger.error("Seedcode checkin failed: " + e.getMessage(), e);
            throw e;
        }
    }

    private static void cleanupLocalRepository(File localRepoPath) throws IOException {
        //Clean the existing local repo
        if (localRepoPath.exists() && localRepoPath.isDirectory()) {
            FileUtils.deleteDirectory(localRepoPath);
            logger.info("Cleaned up existing local folder with same path");
        }
    }

    private static void downloadModelBuildSeedcodeToLocal() throws Exception {
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.fromName(getRegion())).build();
        File seedcodeFile = new File(SEEDCODE_LOCAL_PATH_ZIP_FILE);
        s3Client.getObject(new GetObjectRequest(getSeedcodeBucketName(), getSeedcodeBucketKey()), seedcodeFile);
    }

    private static void extractSeedCode() throws Exception {
        ZipFile zipFile = new ZipFile(SEEDCODE_LOCAL_PATH_ZIP_FILE);
        zipFile.extractAll(TEMP_PATH + getRepositoryFullName());
        logger.info("Seed code has been extracted to local repository");
    }

    private static void commitAndPushAllFiles(Git git, CredentialsProvider credentialsProvider) throws Exception {
        git.add().addFilepattern(".").call();

        final RevCommit revCommit = git.commit()
                .setMessage(SEEDCODE_COMMIT_MESSAGE)
                .setCommitter(SEEDCODE_COMMITTER_NAME, SEEDCODE_COMMITTER_EMAIL)
                .setAuthor(SEEDCODE_COMMITTER_NAME, SEEDCODE_COMMITTER_EMAIL)
                .call();
        RefSpec refSpec = new RefSpec(getRepositoryBranch());
        git.push()
                .setRemote(ORIGIN_REMOTE_REPOSITORY_NAME)
                .setCredentialsProvider(credentialsProvider)
                .setRefSpecs(refSpec)
                .call();
    }

    private static boolean isSeedCodeAlreadyBeenPushed(Git git) throws Exception {
        Iterable<RevCommit> log = git.log().call();
        for (Iterator<RevCommit> iterator = log.iterator(); iterator.hasNext();) {
            RevCommit rev = iterator.next();
            if (SEEDCODE_COMMIT_MESSAGE.equals(rev.getFullMessage())
                    && SEEDCODE_COMMITTER_EMAIL.equals(rev.getCommitterIdent().getEmailAddress())){
                logger.info("Seedcode has been pushed to the repository already");
                return true;
            }
        }
        return false;
    }

    private static void updateSeedCode() throws Exception {
        List<String> substitutionLines = getReplacementEnvVars();
        if (substitutionLines.size() > 0 ) {
            File seedCodeUpdateFile = new File(getSeedCodeUpdateFileLocation());
            String seedCodeUpdateFileContent = FileUtils.readFileToString(seedCodeUpdateFile, FILE_ENCODING);
            for (String line : substitutionLines) {
                String[] substitutionStrings = line.split(SEEDCODE_SUBSTITUTION_FILE_SEPARATOR);
                // Content in substitution file in below format
                // @@@SAGEMAKER_PROJECT_NAME@@@,git3pPipelineProject
                // @@@SAGEMAKER_PROJECT_ID@@@,p-0jxp18sasas8
                if (substitutionStrings.length == 2) {
                    seedCodeUpdateFileContent = seedCodeUpdateFileContent.replace(substitutionStrings[0], substitutionStrings[1]);
                    logger.info(String.format("%s updated to %s", substitutionStrings[0], substitutionStrings[1]));
                }
            }
            FileUtils.writeStringToFile(seedCodeUpdateFile, seedCodeUpdateFileContent, FILE_ENCODING);
            logger.info(String.format("Seedcode file %s updated", seedCodeUpdateFile.getName()));
        }
    }

    private static List<String> getReplacementEnvVars() throws Exception {
        ArrayList<String> result = new ArrayList<String>();
        Map<String, String> env = System.getenv();
        for (String envName : env.keySet()) {
            if (!envName.startsWith("REPLACE_")) continue;

            String replaceKey = envName.replaceAll("REPLACE_", "");
            String replaceValue = getEnvironmentVariable(envName);

            result.add("@@@" + replaceKey + "@@@" + SEEDCODE_SUBSTITUTION_FILE_SEPARATOR + replaceValue);
        }
        return result;
    }

    private static String getSeedCodeUpdateFileLocation() throws Exception {
        return TEMP_PATH + getRepositoryFullName() + "/" + getSeedCodeUpdateFileName();
    }

    private static String getRegion() throws Exception {
        return getEnvironmentVariable("AWS_REGION");
    }

    private static String getConnectionArn() throws Exception {
        return getEnvironmentVariable("GIT_REPOSITORY_CONNECTION_ARN");
    }

    private static String getSeedcodeBucketName() throws Exception {
        return getEnvironmentVariable("SEEDCODE_BUCKET_NAME");
    }

    private static String getSeedcodeBucketKey() throws Exception {
        return getEnvironmentVariable("SEEDCODE_BUCKET_KEY");
    }

    private static String getRepositoryFullName() throws Exception {
        return getEnvironmentVariable("GIT_REPOSITORY_FULL_NAME");
    }

    private static String getRepositoryBranch() throws Exception {
        return getEnvironmentVariable("GIT_REPOSITORY_BRANCH");
    }

    private static String getSeedCodeUpdateFileName() throws Exception {
        return getEnvironmentVariable("SEED_CODE_UPDATE_FILE_NAME");
    }

    private static String getSageMakerProjectName() throws Exception {
        return getEnvironmentVariable("SAGEMAKER_PROJECT_NAME");
    }

    private static String getSageMakerProjectId() throws Exception {
        return getEnvironmentVariable("SAGEMAKER_PROJECT_ID");
    }

    private static String getEnvironmentVariable(String variableKey) throws Exception {
        if (System.getenv(variableKey) == null) {
            throw new Exception("Invalid environment variable:" + variableKey);
        }
        else {
            return System.getenv(variableKey);
        }
    }

    private static Git getGitRepository(URL cloneUrl, File localRepositoryPath, CredentialsProvider credentialsProvider)
            throws Exception {
        Git git = Git.cloneRepository()
                .setURI(cloneUrl.toString())
                .setDirectory(localRepositoryPath)
                .setBranch(getRepositoryBranch())
                .setCredentialsProvider(credentialsProvider)
                .call();
        return git;
    }

    private static String getPath(String repositoryFullName, String connectionArn) {
        Arn arn = Arn.fromString(connectionArn);
        return String.format("git-http/%s/%s/%s/%s",
                arn.getAccountId(),
                arn.getRegion(),
                arn.getResource().getResource(),
                repositoryFullName + ".git");
    }

    private static URL getCodeStarConnectionsEndpointUrl(String region) throws Exception {
        return new URL("https://codestar-connections." + region + ".amazonaws.com/");
    }
}
